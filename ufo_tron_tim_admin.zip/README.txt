TRO TIM UFO — HUONG DAN

Xem thu:
- Giai nen file ZIP.
- Mo index.html bang Chrome.

Dang web cong khai bang GitHub Pages tren dien thoai:
1. Dang nhap https://github.com va tao repository moi ten ufo-tron-tim, chon Public.
2. Add file > Upload files, tai index.html len thu muc goc va Commit changes.
3. Vao Settings > Pages.
4. Build and deployment: Deploy from a branch; Branch main; folder /(root); Save.
5. Cho GitHub Pages trien khai. Link co dang:
   https://TEN-GITHUB.github.io/ufo-tron-tim/

Cach choi:
- Nhap ten nguoi tron, moi dong mot ten.
- Co the tai nhieu anh. Nen dat ten file anh giong ten nguoi choi.
- Bam “BAT DAU — CHO 5 GIAY TRON”.
- Sau 5 giay, ADMIN di tim; bam “ADMIN TIM TIEP” de mo tung nguoi duoc tim theo thu tu ngau nhien.
- Anh chi xu ly trong trinh duyet, khong tu tai len may chu.
- Day la web tinh; danh sach khong dong bo giua cac dien thoai.
